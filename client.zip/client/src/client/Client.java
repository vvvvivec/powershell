/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.sql.*;
import com.mysql.jdbc.Driver;
/**
 *
 * @author n00822782
 */

public class Client {

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       try 
       {
            Connection con = DriverManager.getConnection("jdbc:mysql//host:port ","user","pass");
            Statement stmt = con.createStatement();
            ResultSet results = stmt.executeQuery("SELECT * FROM players");

            while(results.next())
            {
                System.out.println(results.toString());
            }
            
            con.close();
       }
       catch(SQLException e)
       {

       }
    }
    
}
